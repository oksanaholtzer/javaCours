package springTraining;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Entry {
	@Autowired 
	IMusisien pianist;
	
	public void run () {
		//AnnotationConfigApplicationContext myContextConfig= new AnnotationConfigApplicationContext (AppConfig.class);
		
		
		pianist.getInstrument().playMusic();
	}

}
