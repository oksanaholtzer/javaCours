package springTraining.aspect;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;



@Component
@Aspect
public class MyAspectInterceptor {
	static Logger log= LogManager.getLogger(MyAspectInterceptor.class);
	public void instrumentPlay () {
		System.out.println ("An instrument play...");
	}
	
/*	@Before("execution(* springTraining.*.toString())")
	public void interceptToString() {
	System.out.println("To String will be called!!");
	}*/
	
	@AfterReturning(pointcut = "execution(* springTraining.musician.*.toString(..))", returning = "result")
	public void interceptToStringReturning(String result) {
	System.out.println("ToString have returned: " + result);
	}
	
	@MonAnnotation(methodeEcouteeViaAnnotation = 0)
	public void methodeEcouteeViaAnnotation() {
		System.out.println ("j ecoute");
	}
	
	@Before("@annotation(springTraining.aspect.MonAnnotation)")
	public void beforeAnnotation() {
	System.out.println("from my Annotation !");
	}

}
