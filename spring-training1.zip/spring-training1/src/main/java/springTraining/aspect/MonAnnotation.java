package springTraining.aspect;

import java.lang.annotation.*;

@Retention (RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public  @interface MonAnnotation {
	
	public int  methodeEcouteeViaAnnotation() ;

}
