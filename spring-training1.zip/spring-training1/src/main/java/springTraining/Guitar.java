package springTraining;

import org.springframework.stereotype.Component;

@Component ("guitar")
public class Guitar implements Instrument{

	public void playMusic() {
		System.out.println ("Play guitar");
		
	}

}
