package springTraining;

public interface Instrument {
	public void playMusic ();
	
	
	

}
