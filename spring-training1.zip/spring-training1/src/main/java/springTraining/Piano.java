package springTraining;

import org.springframework.stereotype.Component;

@Component ("piano")
public class Piano implements Instrument{

	public void playMusic() {
		System.out.println ("Play piano");
		
	}

}
