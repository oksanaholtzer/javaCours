package springTraining;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext myContext= new ClassPathXmlApplicationContext ("classpath:application-context.xml");
		
		AnnotationConfigApplicationContext myContextConfig= new AnnotationConfigApplicationContext (AppConfig.class);
		myContextConfig.getBeanFactory().createBean(Entry.class).run();
		
		IMusisien musisien= (IMusisien) myContext.getBean("guitarist");
		musisien.getInstrument().playMusic();

	}

}
