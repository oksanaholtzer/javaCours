package springTraining;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan ({"springTraining"})
public class AppConfig {
	@Bean
	public Instrument guitar () {
		return new Guitar();
		
	}
	
	@Bean
	public IMusisien guitarist () {
		return new Guitarist();
	}

}
