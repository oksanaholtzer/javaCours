package springTraining;

public interface IMusisien {
	
 public void play();
 
 public Instrument getInstrument();
 
 public void setInstrument(Instrument instrument);
 
 public String toString();
 
 
}
