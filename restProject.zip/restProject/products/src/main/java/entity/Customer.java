package entity;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	
	private String idCustomer;
	
	private String name;
	private String firstName;
	
	private List<Product> products= new ArrayList<Product>();

	public Customer(String idCustomer, String name, String firstName, List<Product> products) {
		super();
		this.idCustomer = idCustomer;
		this.name = name;
		this.firstName = firstName;
		this.products = products;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getIdCustomer() {
		return idCustomer;
	}

	public void setIdCustomer(String idCustomer) {
		this.idCustomer = idCustomer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	public void addProduct(Product product) {
		if (products==null) {
			 products= new ArrayList<Product>();
		}
		products.add(product);
	}
	

}
