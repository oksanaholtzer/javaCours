package entity;

import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

public class Provider {
	
	private String idProvider;
	private String nameProvider;
	
	
	@ManyToOne (fetch=FetchType.EAGER)
	private Product product;


	public Provider(String idProvider, String nameProvider, Product product) {
		super();
		this.idProvider = idProvider;
		this.nameProvider = nameProvider;
		this.product = product;
	}


	public Provider() {
		super();
		
	}


	public String getIdProvider() {
		return idProvider;
	}


	public void setIdProvider(String idProvider) {
		this.idProvider = idProvider;
	}


	public String getNameProvider() {
		return nameProvider;
	}


	public void setNameProvider(String nameProvider) {
		this.nameProvider = nameProvider;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}
	
	

}
