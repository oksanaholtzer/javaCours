package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.OneToMany;



public class Category {
	String idCat;
	
	//@OneToMany(mappedBy = "id")
	List <Product> products;

	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Category(String idCat, List<Product> products) {
		super();
		this.idCat = idCat;
		this.products = products;
	}

	public String getIdCat() {
		return idCat;
	}

	public void setIdCat(String idCat) {
		this.idCat = idCat;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	public void addProduct(Product product) {
		if (products==null) {
			 products= new ArrayList<Product>();
		}
		products.add(product);
	}
	
	

}
