package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

import config.JsonPropertyView;

@XmlRootElement


public class Product {
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int id;
	@JsonView (JsonPropertyView.Basic.class)
	private String name;
	private String desc;
	
	@JsonIgnore
	@ManyToOne (fetch=FetchType.EAGER)
	private Category category;
	
	
	@OneToMany
	private List <Provider> providers= new ArrayList<Provider>();
	
	
	public Product(int id, String name, String desc) {
		super();
		this.id = id;
		this.name = name;
		this.desc = desc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public void addProvider(Provider provider) {
		if (providers==null) {
			providers= new ArrayList<Provider>();
		}
		providers.add(provider);
	}
	
	
	
	

}
