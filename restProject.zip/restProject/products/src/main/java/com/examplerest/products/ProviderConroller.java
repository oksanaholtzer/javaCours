package com.examplerest.products;

import java.lang.reflect.Field;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ReflectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import dao.IProductDAO;
import dao.IProviderDAO;
import entity.Product;
import entity.Provider;

@RestController
public class ProviderConroller {
	//@Autowired
		IProviderDAO providerdao;
		

		@GetMapping("/provider")
		public Provider provider() {
			Provider provider= new Provider();
			provider.setIdProvider("1");
			provider.setNameProvider("superprov");
			provider.setProduct(new Product(10 , "cd", "cartel"));
			return provider;
		}
		
		@PostMapping("")
		public Provider add(@Validated @RequestBody Provider provider, BindingResult result) throws Exception {
		if (result.hasErrors()) {
		throw new Exception();
		}
		
		return provider;
		}
		
		@PutMapping("/{id}")
		public ResponseEntity createOne(@RequestBody Provider provider, @PathVariable int id) throws Exception {
			
			
			return new ResponseEntity(provider,HttpStatus.CREATED);
		
		
		}
		
		


}
