package com.examplerest.products;

import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import entity.Category;
import entity.Product;

@RestController
@RequestMapping("/category")
public class CategoryConroller {
	@GetMapping("")
	public Category category() {
		Product product= new Product (3,"film","flash");
		Category cat= new Category ();
		cat.setIdCat("first");
		cat.addProduct(product);
		return cat;
	}
	
	@PostMapping("")
	public Category add(@Validated @RequestBody Category cat, BindingResult result) throws Exception {
	if (result.hasErrors()) {
	throw new Exception();
	}
	
	return cat;
	}

}
