package com.examplerest.products;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import entity.Category;
import entity.Customer;
import entity.Product;


	@RestController
	@RequestMapping("/customer")
	public class CustomerConroller {
		@GetMapping("")
		public Customer customer() {
			Product product= new Product (3,"film","flash");
			Customer customer= new Customer ();
			customer.setFirstName("kris");
			customer.setIdCustomer("1");
			customer.setName("TX");
			customer.addProduct(product);
			return customer;
		}
		
		@PostMapping("")
		public ResponseEntity add(@Validated @RequestBody Customer customer, BindingResult result) throws Exception {
		if (result.hasErrors()) {
		throw new Exception();
		}
		
	 return new ResponseEntity(customer,HttpStatus.OK);
		
		}


}
