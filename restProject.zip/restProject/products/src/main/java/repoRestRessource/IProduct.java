package repoRestRessource;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import entity.Product;

@RepositoryRestResource (path="/product")
public interface IProduct extends JpaRepository<Product, Integer>{
	
	@Query("select p from Product  where p.name = ?1")
	 List<Product> findByName(String name);

}
