package config;

public interface JsonPropertyView {
	
	public interface Basic {};
	public interface Color extends Basic {};
		


}
