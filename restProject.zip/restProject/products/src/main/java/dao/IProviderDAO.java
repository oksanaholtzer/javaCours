package dao;

import java.util.List;


import entity.Provider;

public interface IProviderDAO extends IGenericDao<Provider>{
abstract List <Provider> findAll() ;
	
	abstract List<Provider> findBy (String param);
	
	abstract void delete(Provider provider);
	
	abstract void update(Provider provider);
	
	abstract void create(Provider provider);

}
