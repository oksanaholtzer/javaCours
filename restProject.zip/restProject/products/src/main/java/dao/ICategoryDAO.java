package dao;

import java.util.List;

import entity.Category;



public interface ICategoryDAO extends IGenericDao<Category>{
abstract List <Category> findAll() ;
	
	abstract List<Category> findBy (String param);
	
	abstract void delete(Category category);
	
	abstract void update(Category category);
	
	abstract void create(Category category);
	
}
