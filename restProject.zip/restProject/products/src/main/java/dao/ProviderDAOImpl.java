package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import entity.Provider;



@Repository
@Transactional
public class ProviderDAOImpl implements IProviderDAO {
	
	@PersistenceContext
	private EntityManager em;

	public void update(Provider provider) {
		em.merge(em.find(Provider.class, provider.getIdProvider()));
		
	}

	public void delete(Provider provider) {
		em.remove(provider);
		
	}

	public void create(Provider provider) {
		em.persist(provider);
		
	}
	public List findAll() {
		
		Query query =  em.createQuery("from Provider provider ");
		return query.getResultList();
	}

	public List findBy(String param) {
		Query query =  em.createQuery("from Provider provider where id:=idPrd ");
		query.setParameter("idPrd", param);
		return query.getResultList();
	}


}
