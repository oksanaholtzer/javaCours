package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import entity.Category;
import entity.Product;

public class CategoryDAOImpl implements ICategoryDAO{
	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Category> findAll() {

		Query query =  em.createQuery("from Category cat ");
		return query.getResultList();
	}

	@Override
	public List<Category> findBy(String param) {
		Query query =  em.createQuery("from Category cat where idCat:=id ");
		query.setParameter("id", param);
		return query.getResultList();
	}

	@Override
	public void delete(Category category) {
		em.remove(category);
		
	}

	@Override
	public void update(Category category) {
		em.merge(em.find(Category.class, category.getIdCat()));
		
	}

	@Override
	public void create(Category category) {
		em.persist(category);
		
	}

}
