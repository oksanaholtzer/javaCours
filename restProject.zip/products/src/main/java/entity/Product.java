package entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement


public class Product {
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int id;
	private String name;
	private String desc;
	
	
	
	public Product(int id, String name, String desc) {
		super();
		this.id = id;
		this.name = name;
		this.desc = desc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	

}
