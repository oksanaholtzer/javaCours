package dao;

import java.util.List;


import entity.Product;

public interface IProductDAO extends IGenericDao<Product>{
	abstract List <Product> findAll() ;
	
	abstract List<Product> findBy (String param);
	
	abstract void delete(Product product);
	
	abstract void update(Product product);
	
	abstract void create(Product product);
	
	
}
