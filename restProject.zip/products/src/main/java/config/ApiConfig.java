package config;

import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.*;

import java.util.List;

import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.*;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ApiConfig implements WebMvcConfigurer{
	public MappingJackson2HttpMessageConverter jsonConverter() {
		MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
		ObjectMapper objectMapper = jsonConverter.getObjectMapper();
		//objectMapper.registerModule(new Hibernate5Module());
		return jsonConverter;
		}
		public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		converters.add(this.jsonConverter());
		}
	

}
