import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { MenuMain } from './menu-main.component';
import { Person } from './parent1/person.component';
import { Product } from './child11/product-ch.component';
import { CountLettersPipePipe } from './pipe/count-letters-pipe.pipe';
import { SupplyComponent } from './child12/supply/supply.component';
import { ShowPriceDirective } from './directive/show-price.directive';
import { ProductFormComponent } from './forms/product-form/product-form.component'


@NgModule({
  declarations: [
    AppComponent , MenuMain ,Person ,Product, CountLettersPipePipe, SupplyComponent, ShowPriceDirective, ProductFormComponent
  ],
  imports: [
    BrowserModule,FormsModule

      ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
