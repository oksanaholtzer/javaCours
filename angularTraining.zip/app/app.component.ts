import { Component } from '@angular/core';
import {NgForm} from '@angular/forms';



@Component({
  selector: 'myapp-root',
  templateUrl: './app.component.html',
  styleUrls: ['./menuMain.css']
})
export class AppComponent {
  title = 'ang1pr';
  color = 'red';
   firstname: string = 'Stephane';

  changeName(name: string): void {
    this.firstname = name;
  }
  changeColor () {
    this.color = 'green';
  }

}
