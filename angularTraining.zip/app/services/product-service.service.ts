import { Injectable  } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
products =['Book','Film','Music'];
  constructor() { }

  getMyList() : Promise<string[]> {
    return new Promise(resolve => resolve(this.products));
  }

  addtoList(newProduct:string) :  Promise<string[]> {
    this.products.push(newProduct);
    return new Promise(resolve => resolve(this.products));
  }

  getOne(indexToFind:number) :  Promise<string> {

    return new Promise(resolve => resolve(this.products[indexToFind]));
  }

 /* delete(indexToFind:number) :  Promise<string []> {
    this.products.slice(indexToFind,1);
    return new Promise(resolve => resolve(this.products));
  }*/
}
