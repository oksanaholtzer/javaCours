import { Input ,Output ,HostListener  } from '@angular/core';
import { Component  } from '@angular/core';
import { EventEmitter  } from '@angular/core';



@Component({
  selector: 'product,[product]\'',
  templateUrl: './product-child.html',
  styleUrls: ['../app.component.css']
})
export class Product {
  @Input() childMessage: string;
  @Output()
  outputVar: EventEmitter<string> = new EventEmitter();

  mes_parent:string ="coucou";

  @HostListener('click')
  callParent() {
    this.outputVar.emit(this.mes_parent);
  }


}
