import { Component } from '@angular/core';

@Component({
  selector: 'person,[person]\'',
  templateUrl: './person.html',
  styleUrls: ['../app.component.css']
})
export class Person {
  parentMessageBook :string = "Books";
  parentMessageFilm :string = "Films";
  parentMessageMusic :string = "Music";

  parentMessages=['Books','Films','Music'];

  accnumbers=['112233445567','123456789','121'];

  message:string="wait";
    receiveMessage(value: string) {
    this.message = value;
      console.log(value);
  }
}

