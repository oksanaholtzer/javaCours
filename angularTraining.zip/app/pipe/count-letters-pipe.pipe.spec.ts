import { CountlettLettersPipePipe } from './count-letters-pipe.pipe';

describe('CountlettLettersPipePipe', () => {
  it('create an instance', () => {
    const pipe = new CountlettLettersPipePipe();
    expect(pipe).toBeTruthy();
  });
});
