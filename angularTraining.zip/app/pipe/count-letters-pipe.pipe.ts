import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'countLettersPipe'
})
export class CountLettersPipePipe implements PipeTransform {
 new_value:string;
  transform(value: string, before:string, after:string): string {
    console.log("Length "+value.length)
    if (value.length>4) {
        this.new_value = value.padEnd(25, '*')

      }
      else {
        this.new_value="value is not valid";
      }
    return this.new_value;
  }

}

