import { Directive, ElementRef , Input ,HostListener} from '@angular/core';

@Directive({
  selector: '[appShowPrice]'
})
export class ShowPriceDirective {

  constructor(private el: ElementRef) {

  }
  @Input()
  showPrice: number;

  @Input()
  productPromo: string;

  color:string='blue';

  @HostListener('mouseenter') onMouseEnter() {
    this.getColor ();
  }
  @HostListener('mouseleave') onMouseLeave() {
   this.getColor();
  }

  getColor (){
    if(this.showPrice>1) {
      this.el.nativeElement.style.background='red';
    } else {
      this.el.nativeElement.style.background='yellow';

    }
  }
  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }



}
