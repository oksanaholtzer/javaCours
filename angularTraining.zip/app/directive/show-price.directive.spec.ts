import { ShowPriceDirective } from './show-price.directive';

describe('ShowPriceDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowPriceDirective();
    expect(directive).toBeTruthy();
  });
});
