import {Component, Input, OnInit} from '@angular/core';
import {ProductService} from "../../services/product-service.service";


@Component({
  selector: 'app-supply,[supply]\'',
  templateUrl: './supply.component.html',
  styleUrls: ['./supply.component.css']
})
export class SupplyComponent implements OnInit {
  @Input()
   acc_number:string="112223356"
  supplies =['test'];

  constructor(private productservice:ProductService) { }

  ngOnInit(): void {
    this.getList();
  }

  getList() {
    this.productservice
      .getMyList().then(list => {
      this.supplies = list
    });
  }

  setAccNumber (accnumber) {
   this.acc_number=accnumber;

  }
}
