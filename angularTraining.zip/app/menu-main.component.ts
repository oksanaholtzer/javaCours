import { Component } from '@angular/core';

@Component({
  selector: 'menuMain,[menuMain]\'',
  templateUrl: './menuMain.html',
  styleUrls: ['./menuMain.css']
})
export class MenuMain {

}
