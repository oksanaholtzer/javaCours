package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAO;
import model.User;

/**
 * Servlet implementation class HelloServlet
 */
@WebServlet (value="/hello"  )
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDAO udao= new UserDAO ();
	List<User> listUsers= new ArrayList();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
    public HelloServlet() {
    	
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		udao= new UserDAO ();
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.getWriter().println("<h1 style=\"color:red\">hello</h1> ");
		
		System.out.println(request.getParameter("user"));
		request.setAttribute("user", udao.getMapUser().get("Jack"));
		
		List<User> listUsers= new ArrayList();
		listUsers.add(new User("Stef", "St", "2000"));
		listUsers.add(new User("Kristina", "Jack", "2000"));
		listUsers.add(new User("Nico", "Jack", "2000"));
		request.setAttribute("userList", listUsers);
		if(request.getParameter("action").equals("list")) {
			request.getRequestDispatcher("/WEB-INF/pages/listUsers.jsp").forward(request, response);;
	} else if(request.getParameter("action").equals("user")){
		request.getRequestDispatcher("/WEB-INF/pages/showUser.jsp").forward(request, response);
	} else if(request.getParameter("action").equals("adduser")){
		request.getRequestDispatcher("/WEB-INF/pages/addUser.jsp").forward(request, response);
	}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		udao.getMapUser().put("newComer" , new User (request.getParameter("lastName"), request.getParameter("firstname"), "200"));
		
		updateUsers(request.getParameter("lastName"), request.getParameter("firstname"));
		request.setAttribute("userList", listUsers);
		request.setAttribute("valueToTest", 10);
		request.getRequestDispatcher("/WEB-INF/pages/listUsers.jsp").forward(request, response);
		//doGet(request, response);
	}
	
	public void updateUsers (String lastname, String firstname) {
		if(listUsers==null) {
			listUsers= new ArrayList<User>();
		}
		listUsers.add(new User(lastname, firstname, "2000"));
		
	}

}
