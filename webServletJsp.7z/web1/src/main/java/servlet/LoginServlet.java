package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import model.Login;




@WebServlet (value="/login"  )
public class LoginServlet extends HttpServlet{
	Set<Login> listUsers= new HashSet<Login>();
	Map <String,Login> mapLogins=new HashMap<String, Login> ();

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		if(request.getParameter("action")!=null && request.getParameter("action").equals("login")) {
			request.getRequestDispatcher("/WEB-INF/pages/login.jsp").forward(request, response);;
	} else if(request.getParameter("action")!=null && request.getParameter("action").equals("logout")) {
		request.getRequestDispatcher("/WEB-INF/pages/logout.jsp").forward(request, response);;
	}else if  (request.getParameter("action")!=null && request.getParameter("action").equals("deleteLogin")) {
		String loginName=request.getParameter("loginName");
		if(deleteLogin (session , loginName)) {
			request.setAttribute("loginName",loginName);  
            request.getRequestDispatcher("/WEB-INF/pages/loginDeleted.jsp").forward(request, response); 
        } else {
        	request.getRequestDispatcher("/WEB-INF/pages/loginError.jsp").forward(request, response); 
        }
	} else if  (request.getParameter("action")!=null && request.getParameter("action").equals("listLogins")) {
		List<Login> listLogins=new ArrayList<Login> ();
		Set<String> logins=mapLogins.keySet();
		session.setAttribute("loginsList", logins);
		
            request.getRequestDispatcher("/WEB-INF/pages/listLogins.jsp").forward(request, response); 
        
	}
	else
	{
		request.getRequestDispatcher("/WEB-INF/pages/addUser.jsp").forward(request, response);
	}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		HttpSession session=request.getSession();
		if(request.getParameter("action")!=null && request.getParameter("action").equals("addLogin")) {
		String login=request.getParameter("login");  
	        String password=request.getParameter("password");  
	        if(addLogin (session , login , password)) {
	        	session.setAttribute("login",login);  
	            request.getRequestDispatcher("/WEB-INF/pages/userPage.jsp").forward(request, response); 
	        } else {
	        	request.getRequestDispatcher("/WEB-INF/pages/loginError.jsp").forward(request, response); 
	        }
        
		} 
    }
	
	public boolean addLogin (HttpSession session , String login , String mp) {
		if(listUsers== null) {
			listUsers=new HashSet<Login>();
		}
		
		if(!mapLogins.containsKey(login)) {
			Login loginNew = new Login (login, mp);
			mapLogins.put(login, loginNew);
			session.setAttribute("loginList",listUsers); 
			return true;
		}
		
		return false;
	}
	
	public boolean deleteLogin (HttpSession session , String login ) {
		if(listUsers== null) {
			listUsers=new HashSet<Login>();
		}
		
		if(mapLogins.containsKey(login)) {
			
			mapLogins.remove(login);
			session.setAttribute("loginList",listUsers); 
			return true;
		}
		
		return false;
	}
	
	
	

}
