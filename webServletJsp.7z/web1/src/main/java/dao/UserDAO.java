package dao;
import java.util.HashMap;
import java.util.Map;

import model.*;

public class UserDAO {
	Map <String ,User> mapUser= new HashMap <String, User> (); 
			
	public UserDAO	() {
		mapUser.put("Jack", new User("John", "Jack", "2000"));
		mapUser.put("Bob", new User("Bob", "Dilan", "3000"));
		mapUser.put("Alicia", new User("Alicia", "Keys", "4000"));
		
	}

	public Map<String, User> getMapUser() {
		return mapUser;
	}

	public void setMapUser(Map<String, User> mapUser) {
		this.mapUser = mapUser;
	}	
	
	
	

}
