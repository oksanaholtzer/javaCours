package model;

public class User {
	private String lastName;
	private String firstname;
	private String salary;
	public String getLastName() {
		return lastName;
	}
	
	
	public User(String lastName, String firstname, String salary) {
		super();
		this.lastName = lastName;
		this.firstname = firstname;
		this.salary = salary;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	public String getFullname () {
		return firstname+" "+lastName;
	}
	

}
