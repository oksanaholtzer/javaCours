package artifact3.dao;

import java.util.List;

import artifact3.entity.User;

public interface IUserDAO extends IGenericDao<User>{
	abstract List <User> findAll() ;
	
	abstract List<User> findBy (String param);
	
	abstract void delete(User user);
	
	abstract void update(User user);
	
	abstract void create(User user);
	
	
}
