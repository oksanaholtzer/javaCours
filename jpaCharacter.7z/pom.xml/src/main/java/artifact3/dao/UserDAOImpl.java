package artifact3.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import artifact3.entity.User;




public class UserDAOImpl implements IUserDAO{

	public void update(User user) {
		EntityManager em=artifact3.util.EntityManagerSingleton.getInstanse().getEm();
		EntityTransaction transaction =em.getTransaction() ;
		try {
		transaction.begin();
		em.merge(user);
		em.persist(user);
		transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		} finally {
			em.close();
		} 
		
		
	}

	public void delete(User user) {
		EntityManager em=artifact3.util.EntityManagerSingleton.getInstanse().getEm();
		EntityTransaction transaction =em.getTransaction() ;
		try {
		transaction.begin();
		em.remove(user);
		em.persist(user);
		transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		} finally {
			em.close();
		} 
		
	}

	public void create(User user) {
		EntityManager em=artifact3.util.EntityManagerSingleton.getInstanse().getEm();
		EntityTransaction transaction =em.getTransaction() ;
		try {
		transaction.begin();
	
		em.persist(user);
		transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		} finally {
			em.close();
		} 
		
	}
	public List findAll() {
		EntityManager em=artifact3.util.EntityManagerSingleton.getInstanse().getEm();
		EntityTransaction transaction =em.getTransaction() ;
		try {
		transaction.begin();
		
		 Query query =  em.createQuery("from User user ");
		return query.getResultList();
		
		} catch (Exception e) {
			transaction.rollback();
		} finally {
			em.close();
		}
		return null; 
	}

	public List findBy(String param) {
		EntityManager em=artifact3.util.EntityManagerSingleton.getInstanse().getEm();
		EntityTransaction transaction =em.getTransaction() ;
		try {
		transaction.begin();
		 Query query =  em.createQuery("from User user where user.login=:lgn ");
		 query.setParameter("lgn", param);
		return query.getResultList();
		
		} catch (Exception e) {
			transaction.rollback();
		} finally {
			em.close();
		}
		return null; 
	}

}
