package artifact3.dao;

import java.util.List;

public interface  IGenericDao <T> {
	abstract List <T> findAll() ;
	
	abstract List<T> findBy (String param);
	
	abstract void update (T t);
	
	abstract void delete (T t);
	
	abstract void create (T t);



}
