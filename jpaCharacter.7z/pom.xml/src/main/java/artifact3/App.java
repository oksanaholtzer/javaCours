package artifact3;

import java.util.List;

import artifact3.dao.UserDAOImpl;
import artifact3.entity.User;

public class App {

	public static void main(String[] args) {
		UserDAOImpl userDao = new UserDAOImpl();
        
        User user1 = new User ("1", "firstU", "first@gmail.com");
        userDao.create(user1);
        
        User user2 = new User ("2", "secondeU", "seconde@gmail.com");
        userDao.create(user2);
        
        User user3 = new User ("3", "thirdU", "third@gmail.com");
        userDao.create(user3);
        
        User user4 = new User ("4", "forthU", "forth@gmail.com");
        userDao.create(user4);
        
        List listUser=userDao.findAll();
        userDao.delete(user4);

	}

}
