package artifact3.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class EntityManagerSingleton {
	private static EntityManagerFactory emFactory;
	private static EntityManager em;
	
	private EntityManagerSingleton () {
		emFactory=Persistence.createEntityManagerFactory("trJPA");
		em =  emFactory.createEntityManager();
	}
	
	public static EntityManagerSingleton getInstanse () {
		return new EntityManagerSingleton () ;
		
	}

	public static EntityManager getEm() {
		return em;
	}

	public static void setEm(EntityManager em) {
		EntityManagerSingleton.em = em;
	}

}
