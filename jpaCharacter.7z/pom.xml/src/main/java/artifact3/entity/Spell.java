package artifact3.entity;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Spell extends LevelElement{
	public Spell(String name, String level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}
	private int cost;
	 private int damage;

}
