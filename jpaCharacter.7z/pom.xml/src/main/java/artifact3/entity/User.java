package artifact3.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="user")
public class User {
	
	
	@Id
	@Column(name = "ID_USER")
	private String id;
	
	@Column(name = "LOGIN")
	private String login;
	
	@Column(name = "EMAIL")
	private String email;

	public User(String id, String login, String email) {
		super();
		this.id = id;
		this.login = login;
		this.email = email;
	}
	
	@OneToMany(mappedBy = "ID_CHARACTER")
	List <Character> characters= new ArrayList<Character>();
	
	public void addCharacter (Character character) {
		if(characters==null ) {
			characters=new ArrayList<Character>();
		}
		characters.add(character);
	}
	

}
