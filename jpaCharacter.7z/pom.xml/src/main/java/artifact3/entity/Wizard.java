package artifact3.entity;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Wizard extends Character {
	private int magic;

	public Wizard(String id, String name) {
		super(id, name);
		
	}

}
