package artifact3.entity;

public enum Color {
	BLUE, GREEN,RED

}
