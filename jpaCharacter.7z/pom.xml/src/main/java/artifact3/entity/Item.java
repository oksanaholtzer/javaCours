package artifact3.entity;

import javax.persistence.Embeddable;
import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Item extends LevelElement{

	private int durability;
	 private Color color;
	public Item(String name, String level) {
		super(name, level);
		
	}

}
