package artifact3.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class LevelElementId implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	public String level;
	
	public LevelElementId(String name, String level) {
		super();
		this.name = name;
		this.level = level;
	}
	
	
	
	


}
