package artifact3.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="character")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Character {
	
	@Id
	@Column(name = "ID_CHARACTER")
	private String idChar;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "LEVEL")
	private String level;
	 
	@Column(name = "HEALTH")
	private String health;
	
	@Column(name = "STRENGTH")
	private String strength;

	public Character(String id, String name) {
		super();
		this.idChar = id;
		this.name = name;
	}
	
	
    @ManyToOne
    @JoinColumn(name = "USER_ID", nullable = false)
    private User user;
    
    
   /* @ManyToMany
    @JoinTable( name="levelElement",
    joinColumns = @JoinColumn(name="name"))*/
   
    private List <Item> items=new ArrayList <Item>	();
	
	
	
	

}
