package artifact3.entity;


import javax.persistence.*;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="levelElement")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class LevelElement {
	
	 private LevelElementId levelElId;
	 
	 public LevelElement (String name, String level) {
		 levelElId= new LevelElementId(name, level);
	 }

}
