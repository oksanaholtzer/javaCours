package artifact3.entity;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Orc extends Character {
	private int rage;

	public Orc(String id, String name) {
		super(id, name);
		
	}

}
