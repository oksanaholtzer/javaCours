package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entity.User;

public class UserDAOImpl implements IUserDAO{
	@PersistenceContext
	private EntityManager em;

	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<User> findBy(String param) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(User user) {
		// TODO Auto-generated method stub
		
	}

	public void update(User user) {
		// TODO Auto-generated method stub
		
	}

	public void create(User user) {
		// TODO Auto-generated method stub
		
	}

}
