package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import authentification.UserAuth;

import validation.ProductValidator;

@Controller
public class LoginController {
	
	@PostMapping("/login")
	public String loginUser(@ModelAttribute("login") UserAuth user ,BindingResult result,  Model model) {
	System.out.println("Login : " +user.getLogin() + " Password : " + user.getPassword());
	new ProductValidator().validate(user, result);
	model.addAttribute("login", user);
	return "redirect:/product";
	}


}
