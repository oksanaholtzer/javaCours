package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import entity.Product;
import validation.ProductValidator;

@Controller
public class ProductController {
	@RequestMapping("/product")
	//public String addProduct(@RequestParam String name, @RequestParam float price) {
		public String addProduct(@PathVariable(value="idProduct", required=false) int idProduct, Model model) {
		return "product";
				
	
	}
	
	@PostMapping("/product/new")
	public String addProduct(@ModelAttribute("product") Product product ,BindingResult result,  Model model) {
	System.out.println("Name : " + product.getName() + " Price : " + product.getUnitPrice());
	new ProductValidator().validate(product, result);
	model.addAttribute("product", product);
	return "redirect:/products";
	}

}
