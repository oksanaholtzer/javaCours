package authentification;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.Length;


@Entity
@Table (name="USER_AUTH")
public class UserAuth {
	
	@Length (min=3,message="Lenght of the login should be lohger as 3 caracters")
	private String login;
	
	@NotEmpty
	private String password;
	
	

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
