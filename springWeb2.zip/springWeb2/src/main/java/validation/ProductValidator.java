package validation;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import entity.Product;

public class ProductValidator implements Validator {

	public boolean supports(Class<?> product) {
		return Product.class.equals(product);
		
	}

	public void validate(Object product1, Errors err) {
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "name", "name.empty", "Fill the name please");
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "unitPrice", "unitPrice.empty", "Fill the price please");
		
	}

}
