package config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:data-source.properties")
public class AppConfig {

	@Autowired
	private Environment env;
	@Bean
	public BasicDataSource dataSource() {
	BasicDataSource dataSource = new BasicDataSource();
	dataSource.setUrl(env.getProperty("url"));
	return dataSource;
	}
}
