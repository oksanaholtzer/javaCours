package config;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import entity.*;

public interface ProductRepository extends Repository <Product, Long>{
	
	@Query("select p from Product  where p.description = ?1")
	List<Product> findByDescription(String description);
	
	List<Product> findByPriceBetween (int priceA, int priceB);

}
