package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import entity.Product;




@Repository
@Transactional
public class ProductDAOImpl implements IProductDAO{
	
	@PersistenceContext
	private EntityManager em;

	public void update(Product product) {
		em.merge(em.find(Product.class, product.getId()));
		
	}

	public void delete(Product product) {
		em.remove(product);
		
	}

	public void create(Product product) {
		em.persist(product);
		
	}
	public List findAll() {
		
		Query query =  em.createQuery("from Product product ");
		return query.getResultList();
	}

	public List findBy(String param) {
		Query query =  em.createQuery("from Product product where id:=idPrd ");
		query.setParameter("idPrd", param);
		return query.getResultList();
	}

}
