package entity;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.*;

import config.JpaConfig;
import config.ProductRepository;
import dao.IProductDAO;
import dao.ProductDAOImpl;

public class Entry {

	public static void main(String[] args) {
		//ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext ("classpath:application-context.xml");
		AnnotationConfigApplicationContext annotContext= new AnnotationConfigApplicationContext(JpaConfig.class);
		IProductDAO productDao=annotContext.getBean(ProductDAOImpl.class);
		Product product= new Product();
		product.setName("piano");
		productDao.create(product);
		
		
		ProductRepository productRep=annotContext.getBean(ProductRepository.class);
		IProductDAO productDaorep=annotContext.getBean(ProductDAOImpl.class);
		List <Product> products=productRep.findByDescription("test");

	}

}
